package Forms;

public class Property {
	
private static int plotNumberID = 1;
	
	private String plotID = String.valueOf(plotNumberID);
	private int plotNumber;
	private String PlotName;
	private String PropertyClass;
	private String Parcel;
	private String LandUse;
	private String PerChance;
	private String Plots;
	private String Details;
	private String PropertyStatus;
	private int DeedNumber;
	private int NumberOfRooms;
	private int NumberOfBathrooms;
	private int NumberOfAirConditionUnits;
	private int NumberOfFloors;
	private boolean PropertyDelivered;
	private boolean RentalGuarantee;
	private boolean Commited;
	private boolean RentalPlan;
	private boolean GrandView;
	private boolean TitleDeed;
	private boolean Pool;
	private boolean Garden;
	private boolean Parking;
	private boolean PoolHeading;
	private boolean CentralHeading;
	private boolean AirCond;


	public void setPlotNumber(int plotNumber){
		this.plotNumber = plotNumber;
	}
	
	public void setPlotName(String plotName) {
		this.PlotName = plotName;
	}
	
	public void setPropertyClass(String propertyClass) {
		this.PropertyClass = propertyClass;
	}
	
	public void setParcel(String parcel) {
		this.Parcel = parcel;
	}
	
	public void setLandUse(String landUse) {
		this.LandUse = landUse;
	}
	
	public void setPerChance(String perChance) {
		this.PerChance = perChance;
	}
	
	public void setPlots(String plots) {
		this.Plots = plots;
	}
	
	public void setDetails(String details) {
		this.Details = details;
	}
	
	public void setPropertyStatus(String propertyStatus) {
		this.PropertyStatus = propertyStatus;
	}
	
	public void setDeedNumber(int deedNumber) {
		this.DeedNumber = deedNumber;
	}
	
	public void setNumberOfRooms(int numberOfRooms) {
		this.NumberOfRooms = numberOfRooms;
	}
	
	public void setNumberOfBathrooms(int numberOfBathrooms) {
		this.NumberOfBathrooms = numberOfBathrooms;
	}
	
	public void setNumberOfAirConditionUnits(int numberOfAirConditionUnits) {
		this.NumberOfAirConditionUnits = numberOfAirConditionUnits;
	}
	
	public void setNumberOfFloors(int numberOfFloors) {
		this.NumberOfFloors = numberOfFloors;
	}
	
	public String getPlotID() {
		return plotID;
	}
	
	public int getPlotNumber(){
		return plotNumber;
	}
	
	public String getPlotName() {
		return PlotName;
	}
	
	public String getPropertyClass() {
		return PropertyClass;
	}
	
	public String getParcel() {
		return Parcel;
	}
	
	public String getLandUse() {
		return LandUse;
	}
	
	public String getPerChance() {
		return PerChance;
	}
	
	public String getPlots() {
		return Plots;
	}
	
	public String getDetails() {
		return Details;
	}
	
	public String getPropertyStatus() {
		return PropertyStatus;
	}
	
	public int getDeedNumber() {
		return DeedNumber;
	}
	
	public int getNumberOfRooms() {
		return NumberOfRooms;
	}
	
	public int getNumberOfBathrooms() {
		return NumberOfBathrooms;
	}
	
	public int getNumberOfAirConditionUnits() {
		return NumberOfAirConditionUnits;
	}
	
	public int getNumberOfFloors() {
		return NumberOfFloors;
	}
	
	public boolean getPropertyDeli() {
		return PropertyDelivered;
	}
	
	public boolean getRentalGuarantee() {
		return RentalGuarantee;
	}
	
	public boolean getCommited() {
		return Commited;
	}
	
	public boolean getRentalPlan() {
		return RentalPlan;
	}
	
	public boolean getGrandeView() {
		return GrandView;
	}
	
	public boolean getTitleDeed() {
		return TitleDeed;
	}
	
	public boolean getPool() {
		return Pool;
	}
	
	public boolean getGarden() {
		return Garden;
	}
	public boolean getParking() {
		return Parking;
	}
	public boolean getPoolHeading() {
		return PoolHeading;
	}
	
	public boolean getCentralHeading() {
		return CentralHeading;
	}
	
	public boolean getAirCond() {
		return AirCond;
	}
	
	
	


}

